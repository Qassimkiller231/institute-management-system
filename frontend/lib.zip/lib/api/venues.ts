import { API_URL, getHeaders } from './client';

export interface Venue {
  id: string;
  name: string;
  address?: string;
  city?: string;
  capacity?: number;
}

export const venuesAPI = {
  // Get all venues
  getAll: async () => {
    const res = await fetch(`${API_URL}/venues`, {
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to fetch venues');
    return res.json();
  },

  // Get by ID
  getById: async (id: string) => {
    const res = await fetch(`${API_URL}/venues/${id}`, {
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to fetch venue');
    return res.json();
  },

  // Create venue
  create: async (data: Omit<Venue, 'id'>) => {
    const res = await fetch(`${API_URL}/venues`, {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.message || 'Failed to create venue');
    }
    return res.json();
  },

  // Update venue
  update: async (id: string, data: Partial<Venue>) => {
    const res = await fetch(`${API_URL}/venues/${id}`, {
      method: 'PUT',
      headers: getHeaders(true),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.message || 'Failed to update venue');
    }
    return res.json();
  },

  // Delete venue
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/venues/${id}`, {
      method: 'DELETE',
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to delete venue');
    return res.json();
  }
};