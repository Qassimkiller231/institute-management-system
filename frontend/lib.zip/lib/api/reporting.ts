import { API_URL, getHeaders } from './client';

export const reportingAPI = {
  // Dashboard Analytics
  getDashboardAnalytics: async (termId?: string) => {
    const url = termId 
      ? `${API_URL}/reports/dashboard/admin?termId=${termId}`
      : `${API_URL}/reports/dashboard/admin`;
    const res = await fetch(url, {
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to fetch dashboard analytics');
    return res.json();
  },

  // Financial Analytics
  getFinancialAnalytics: async (termId?: string) => {
    const url = termId 
      ? `${API_URL}/analytics/financial?termId=${termId}`
      : `${API_URL}/analytics/financial`;
    const res = await fetch(url, {
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to fetch financial analytics');
    return res.json();
  },

  // Program Analytics
  getProgramAnalytics: async (programId?: string) => {
    const url = programId 
      ? `${API_URL}/analytics/program?programId=${programId}`
      : `${API_URL}/analytics/program`;
    const res = await fetch(url, {
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to fetch program analytics');
    return res.json();
  },

  // Performance Reports
  getPerformanceReports: async (params?: { groupId?: string; studentId?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.groupId) queryParams.append('groupId', params.groupId);
    if (params?.studentId) queryParams.append('studentId', params.studentId);
    
    const url = queryParams.toString() 
      ? `${API_URL}/reports/performance?${queryParams}`
      : `${API_URL}/reports/performance`;
    
    const res = await fetch(url, {
      headers: getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to fetch performance reports');
    return res.json();
  }
};