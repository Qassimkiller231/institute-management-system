"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  enrollmentsAPI,
  studentsAPI,
  groupsAPI,
  programsAPI,
  CreateEnrollmentDto,
  UpdateEnrollmentDto,
} from "@/lib/api";

interface Enrollment {
  id: string;
  status: 'ACTIVE' | 'COMPLETED' | 'DROPPED' | 'IN_PROGRESS' | 'WITHDRAWN';
  enrollmentDate: string;
  student: {
    id: string;
    firstName: string;
    secondName?: string;
    thirdName?: string;
  };
  group: {
    id: string;
    groupCode: string;
    name?: string;
    term: {
      name: string;
      program: {
        id: string;
        name: string;
      };
    };
  };
}

interface Student {
  id: string;
  firstName: string;
  secondName?: string;
  thirdName?: string;
  cpr: string;
}

interface Group {
  id: string;
  groupCode: string;
  name?: string;
  termId: string;
}

interface Program {
  id: string;
  name: string;
}

export default function EnrollmentManagement() {
  const router = useRouter();
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [groupFilter, setGroupFilter] = useState("");
  const [programFilter, setProgramFilter] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [selectedEnrollment, setSelectedEnrollment] = useState<Enrollment | null>(null);
  
  // ✅ Create form state
  const [formData, setFormData] = useState<CreateEnrollmentDto>({
    studentId: "",
    groupId: "",
    status: "ACTIVE",
    enrollmentDate: new Date().toISOString().split("T")[0],
  });
  
  // ✅ Edit form state
  const [editData, setEditData] = useState<UpdateEnrollmentDto>({
    status: "ACTIVE",
    groupId: "",
  });

  // ✅ Search state for student selection
  const [studentSearchTerm, setStudentSearchTerm] = useState("");
  const [showStudentDropdown, setShowStudentDropdown] = useState(false);

  useEffect(() => {
    fetchEnrollments();
    fetchStudents();
    fetchGroups();
    fetchPrograms();
  }, []);

  const fetchEnrollments = async () => {
    try {
      setLoading(true);
      const data = await enrollmentsAPI.getAll();
      setEnrollments(data.data || []);
    } catch (err) {
      console.error("Error:", err);
      alert("Failed to fetch enrollments");
    } finally {
      setLoading(false);
    }
  };

  const fetchStudents = async () => {
    try {
      const data = await studentsAPI.getAll();
      setStudents(data.data || []);
    } catch (err) {
      console.error("Error:", err);
    }
  };

  const fetchGroups = async () => {
    try {
      const data = await groupsAPI.getAll();
      setGroups(data.data || []);
    } catch (err) {
      console.error("Error:", err);
    }
  };

  const fetchPrograms = async () => {
    try {
      const data = await programsAPI.getAll();
      setPrograms(data.data || []);
    } catch (err) {
      console.error("Error:", err);
    }
  };

  // ✅ Create handler
  const handleCreate = async () => {
    if (!formData.studentId || !formData.groupId) {
      alert("Please select student and group");
      return;
    }

    try {
      await enrollmentsAPI.create(formData);
      alert("Enrollment created successfully!");
      setShowModal(false);
      resetForm();
      fetchEnrollments();
    } catch (err: any) {
      alert("Error: " + err.message);
    }
  };

  // ✅ Update handler - uses editData
  const handleUpdate = async () => {
    if (!selectedEnrollment) return;

    try {
      await enrollmentsAPI.update(selectedEnrollment.id, editData);
      alert("Enrollment updated successfully!");
      setShowModal(false);
      resetForm();
      fetchEnrollments();
    } catch (err: any) {
      alert("Error: " + err.message);
    }
  };

  const handleDelete = async (id: string, studentName: string) => {
    if (!confirm(`Remove enrollment for ${studentName}?`)) return;

    try {
      await enrollmentsAPI.delete(id);
      alert("Enrollment removed successfully!");
      fetchEnrollments();
    } catch (err: any) {
      alert("Error: " + err.message);
    }
  };

  // ✅ Open edit modal - populates editData
  const openEditModal = (enrollment: Enrollment) => {
    setModalMode("edit");
    setSelectedEnrollment(enrollment);
    setEditData({
      groupId: enrollment.group.id,
      status: enrollment.status as 'ACTIVE' | 'COMPLETED' | 'DROPPED',
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      studentId: "",
      groupId: "",
      status: "ACTIVE",
      enrollmentDate: new Date().toISOString().split("T")[0],
    });
    setEditData({
      status: "ACTIVE",
      groupId: "",
    });
    setSelectedEnrollment(null);
    setStudentSearchTerm("");
    setShowStudentDropdown(false);
  };

  // ✅ Get available students (not enrolled in current term)
  const getAvailableStudents = () => {
    if (!formData.groupId) return [];

    const selectedGroup = groups.find(g => g.id === formData.groupId);
    if (!selectedGroup) return [];

    // Find students who are ALREADY enrolled in this term
    const enrolledStudentIds = new Set(
      enrollments
        .filter(e => 
          e.status === 'ACTIVE' && 
          e.group.term.id === selectedGroup.termId // Assuming enrollment -> group -> term relation exists in data
          // Note: The Enrollment interface in this file doesn't explicitly show termId, 
          // but we can infer it from the group if the backend returns it.
          // Let's rely on the group.termId we added to the Group interface.
          // We need to match enrollment's group ID to our groups list to get the term ID.
        )
        .map(e => {
           // Find the full group object for this enrollment to get the termId
           const group = groups.find(g => g.id === e.group.id);
           return group?.termId === selectedGroup.termId ? e.student.id : null;
        })
        .filter(Boolean)
    );

    return students.filter(student => {
      // Filter out already enrolled
      if (enrolledStudentIds.has(student.id)) return false;

      // Search filter (Name or CPR)
      const searchLower = studentSearchTerm.toLowerCase();
      const fullName = `${student.firstName} ${student.secondName || ''} ${student.thirdName || ''}`.toLowerCase();
      
      return fullName.includes(searchLower) || (student.cpr && student.cpr.includes(searchLower));
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "bg-green-100 text-green-800";
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800";
      case "COMPLETED":
        return "bg-purple-100 text-purple-800";
      case "WITHDRAWN":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const filteredEnrollments = enrollments.filter((enrollment) => {
    const studentName = `${enrollment.student.firstName} ${
      enrollment.student.secondName || ""
    } ${enrollment.student.thirdName || ""}`.toLowerCase();
    const matchesSearch =
      studentName.includes(searchTerm.toLowerCase()) ||
      enrollment.group.groupCode
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
    const matchesStatus = !statusFilter || enrollment.status === statusFilter;
    const matchesGroup = !groupFilter || enrollment.group.id === groupFilter;
    const matchesProgram =
      !programFilter || enrollment.group.term?.program?.name === programFilter;

    return matchesSearch && matchesStatus && matchesGroup && matchesProgram;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div>
              <button
                onClick={() => router.push("/admin")}
                className="text-blue-600 hover:text-blue-800 mb-2"
              >
                ← Back to Dashboard
              </button>
              <h1 className="text-3xl font-bold text-gray-900">
                Enrollment Management
              </h1>
            </div>
            <button
              onClick={() => {
                setModalMode("create");
                resetForm();
                setShowModal(true);
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              + Add Enrollment
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <input
            type="text"
            placeholder="Search by student name or group code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
          >
            <option value="">All Statuses</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="ACTIVE">Active</option>
            <option value="COMPLETED">Completed</option>
            <option value="WITHDRAWN">Withdrawn</option>
          </select>
          <select
            value={groupFilter}
            onChange={(e) => setGroupFilter(e.target.value)}
            className="px-4 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
          >
            <option value="">All Groups</option>
            {groups.map((group) => (
              <option key={group.id} value={group.id}>
                {group.groupCode}
              </option>
            ))}
          </select>
          <select
            value={programFilter}
            onChange={(e) => setProgramFilter(e.target.value)}
            className="px-4 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
          >
            <option value="">All Programs</option>
            {programs.map((program) => (
              <option key={program.id} value={program.name}>
                {program.name}
              </option>
            ))}
          </select>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-sm text-gray-600">Total Enrollments</div>
            <div className="text-2xl font-bold text-blue-600">
              {enrollments.length}
            </div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-sm text-gray-600">Active</div>
            <div className="text-2xl font-bold text-green-600">
              {enrollments.filter((e) => e.status === "ACTIVE").length}
            </div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-sm text-gray-600">In Progress</div>
            <div className="text-2xl font-bold text-blue-600">
              {enrollments.filter((e) => e.status === "IN_PROGRESS").length}
            </div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-sm text-gray-600">Withdrawn</div>
            <div className="text-2xl font-bold text-red-600">
              {enrollments.filter((e) => e.status === "WITHDRAWN").length}
            </div>
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-900 uppercase">
                    Student
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-900 uppercase">
                    Group
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-900 uppercase">
                    Program
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-900 uppercase">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-900 uppercase">
                    Enrolled
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-900 uppercase">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredEnrollments.map((enrollment) => (
                  <tr key={enrollment.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                      {enrollment.student.firstName}{" "}
                      {enrollment.student.secondName}{" "}
                      {enrollment.student.thirdName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {enrollment.group.groupCode}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {enrollment.group.term?.program?.name || "N/A"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(
                          enrollment.status
                        )}`}
                      >
                        {enrollment.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(enrollment.enrollmentDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                      <button
                        onClick={() => openEditModal(enrollment)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() =>
                          handleDelete(
                            enrollment.id,
                            `${enrollment.student.firstName} ${enrollment.student.secondName}`
                          )
                        }
                        className="text-red-600 hover:text-red-800"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredEnrollments.length === 0 && (
              <div className="text-center py-12 text-gray-900">
                No enrollments found
              </div>
            )}
          </div>
        )}
      </main>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6 text-gray-900">
              {modalMode === "create" ? "Add Enrollment" : "Edit Enrollment"}
            </h2>

            <div className="space-y-4">
              {modalMode === "create" && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Student *
                  </label>
                  
                  {!formData.groupId ? (
                    <div className="text-gray-500 italic p-2 border rounded bg-gray-50">
                      Please select a group first
                    </div>
                  ) : (
                    <div className="relative">
                      <div
                        className="w-full px-3 py-2 border-2 border-gray-400 rounded-lg cursor-pointer bg-white flex justify-between items-center"
                        onClick={() => setShowStudentDropdown(!showStudentDropdown)}
                      >
                        <span className={formData.studentId ? "text-gray-900" : "text-gray-500"}>
                          {formData.studentId 
                            ? (() => {
                                const s = students.find(s => s.id === formData.studentId);
                                return s ? `${s.firstName} ${s.secondName || ''} ${s.thirdName || ''} (${s.cpr})` : "Select Student";
                              })()
                            : "Select Student (Type to search)"}
                        </span>
                        <span className="text-gray-400">▼</span>
                      </div>

                      {showStudentDropdown && (
                        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                          <div className="p-2 sticky top-0 bg-white border-b">
                            <input
                              type="text"
                              placeholder="Search by Name or CPR..."
                              value={studentSearchTerm}
                              onChange={(e) => setStudentSearchTerm(e.target.value)}
                              className="w-full px-3 py-1 border rounded focus:ring-2 focus:ring-blue-500 outline-none"
                              autoFocus
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                          
                          {getAvailableStudents().length === 0 ? (
                            <div className="p-3 text-gray-500 text-center">
                              No eligible students found
                            </div>
                          ) : (
                            getAvailableStudents().map((student) => (
                              <div
                                key={student.id}
                                onClick={() => {
                                  setFormData({ ...formData, studentId: student.id });
                                  setShowStudentDropdown(false);
                                  setStudentSearchTerm("");
                                }}
                                className={`px-4 py-2 cursor-pointer hover:bg-blue-50 ${
                                  formData.studentId === student.id ? "bg-blue-100" : ""
                                }`}
                              >
                                <div className="font-medium text-gray-900">
                                  {student.firstName} {student.secondName} {student.thirdName}
                                </div>
                                <div className="text-sm text-gray-500">
                                  CPR: {student.cpr}
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Group *
                </label>
                <select
                  value={modalMode === "create" ? formData.groupId : editData.groupId}
                  onChange={(e) => {
                    if (modalMode === "create") {
                      setFormData({ ...formData, groupId: e.target.value });
                    } else {
                      setEditData({ ...editData, groupId: e.target.value });
                    }
                  }}
                  className="w-full px-3 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
                  required
                >
                  <option value="">Select Group</option>
                  {groups.map((group) => (
                    <option key={group.id} value={group.id}>
                      {group.groupCode} {group.name && `- ${group.name}`}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status *
                </label>
                <select
                  value={modalMode === "create" ? formData.status : editData.status}
                  onChange={(e) => {
                    const status = e.target.value as 'ACTIVE' | 'COMPLETED' | 'DROPPED';
                    if (modalMode === "create") {
                      setFormData({ ...formData, status });
                    } else {
                      setEditData({ ...editData, status });
                    }
                  }}
                  className="w-full px-3 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
                >
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="ACTIVE">Active</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="WITHDRAWN">Withdrawn</option>
                </select>
              </div>

              {modalMode === "create" && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Enrollment Date *
                  </label>
                  <input
                    type="date"
                    value={formData.enrollmentDate}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        enrollmentDate: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border-2 border-gray-400 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900"
                    required
                  />
                </div>
              )}
            </div>

            <div className="mt-6 flex space-x-3">
              <button
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={modalMode === "create" ? handleCreate : handleUpdate}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                {modalMode === "create" ? "Create" : "Update"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}