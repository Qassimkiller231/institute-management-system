'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getToken, getStudentId, logout } from '@/lib/auth';
import { announcementsAPI } from '@/lib/api';
import type { Announcement } from '@/lib/api/announcements';

interface StudentData {
  id: string;
  firstName: string;
  secondName?: string;
  currentLevel?: string;
  enrollments: Array<{
    id: string;
    status: string;
    term?: {
      id: string;
      name: string;
      isCurrent: boolean;
    };
    group: {
      id: string;
      name: string;
      level: {
        name: string;
      };
    };
  }>;
  testSessions: Array<{
    id: string;
    status: string;
    completedAt?: string;
  }>;
}

export default function StudentDashboard() {
  const router = useRouter();
  const [student, setStudent] = useState<StudentData | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStudentData();
  }, []);

  const loadStudentData = async () => {
    try {
      const token = getToken();
      const studentId = getStudentId();

      // CRITICAL FIX: Check if token and studentId exist BEFORE making API call
      if (!token || !studentId) {
        console.log('No token or studentId found, redirecting to login');
        router.push('/login');
        return;
      }

      const response = await fetch(
        `http://localhost:3001/api/students/${studentId}`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setStudent(result.data);
          
          // Fetch announcements for active enrollments
          if (result.data.enrollments) {
            const activeGroups = result.data.enrollments
              .filter((e: any) => e.status === 'ACTIVE' && e.term?.isCurrent)
              .map((e: any) => e.group.id);

            if (activeGroups.length > 0) {
              const announcementsPromises = activeGroups.map((groupId: string) => 
                announcementsAPI.getAll({ groupId })
              );
              
              const announcementsResults = await Promise.all(announcementsPromises);
              
              // Combine and deduplicate
              const allAnnouncements = announcementsResults
                .flatMap(res => res.data || [])
                .filter((announcement, index, self) => 
                  index === self.findIndex((a) => a.id === announcement.id)
                );

              // Sort: HIGH priority first, then by date (newest first)
              allAnnouncements.sort((a, b) => {
                const priorityOrder: Record<string, number> = { HIGH: 3, MEDIUM: 2, LOW: 1 };
                const pA = priorityOrder[a.priority] || 0;
                const pB = priorityOrder[b.priority] || 0;
                const priorityDiff = pB - pA;
                
                if (priorityDiff !== 0) return priorityDiff;
                return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
              });

              setAnnouncements(allAnnouncements.slice(0, 5)); // Top 5
            }
          }
        }
      } else if (response.status === 401 || response.status === 403) {
        // Unauthorized - redirect to login
        console.log('Unauthorized, redirecting to login');
        router.push('/login');
      }
    } catch (error) {
      console.error('Error loading student data:', error);
      // On network error, check if we have valid auth
      const token = getToken();
      const studentId = getStudentId();
      if (!token || !studentId) {
        router.push('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  // FIXED: Check for ACTIVE enrollment in CURRENT term
  const hasCompletedTest = student?.currentLevel != null;
  const hasCurrentTermEnrollment = student?.enrollments?.some(
    e => e.status === 'ACTIVE' && e.term?.isCurrent === true
  ) ?? false;
  const hasPastEnrollmentsOnly = (student?.enrollments?.length ?? 0) > 0 && !hasCurrentTermEnrollment;

  // FIXED: Use the logout function from auth.ts which clears everything properly
  const handleLogout = () => {
    logout(); // This will clear everything and redirect to /login
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="text-6xl mb-4">⏳</div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // STATE 1: No test completed yet - Show placement test prompt
  if (!hasCompletedTest) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Welcome, {student?.firstName} {student?.secondName}!
              </h1>
              <p className="text-gray-600">Function Institute Student Portal</p>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 text-gray-600 hover:text-gray-900"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="text-6xl mb-6">📝</div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Complete Your Placement Test
            </h2>
            <p className="text-gray-600 text-lg mb-8">
              To get started with your English learning journey, please take our placement test. 
              It will help us determine the right level for you.
            </p>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 text-left">
              <h3 className="font-semibold text-gray-900 mb-4">What to expect:</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-3">
                  <span className="text-green-600 mt-1">✓</span>
                  <span>Multiple choice questions (45 minutes)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-600 mt-1">✓</span>
                  <span>Speaking test with our teachers (15 minutes)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-600 mt-1">✓</span>
                  <span>Immediate level recommendation</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => router.push('/student/placement-test')}
              className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-700 transition"
            >
              Start Placement Test →
            </button>
          </div>
        </div>
      </div>
    );
  }

  // STATE 2: Has past enrollments but not current term - Show re-enrollment message
  if (hasPastEnrollmentsOnly) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Welcome, {student?.firstName} {student?.secondName}!
              </h1>
              <p className="text-gray-600">Function Institute Student Portal</p>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 text-gray-600 hover:text-gray-900"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="text-6xl mb-6">📚</div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Not Enrolled in Current Term
            </h2>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
              <div className="flex items-start gap-4">
                <div className="text-4xl">⚠️</div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    You were previously enrolled
                  </h3>
                  <p className="text-gray-700">
                    Our records show you were a student in a previous term, but you are not 
                    currently enrolled in the active term.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 text-left">
              <h3 className="font-semibold text-gray-900 mb-4">To re-enroll:</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-3">
                  <span className="text-blue-600 mt-1">1.</span>
                  <span>Contact the administration office</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-blue-600 mt-1">2.</span>
                  <span>Complete registration for the current term</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-blue-600 mt-1">3.</span>
                  <span>Make required payments</span>
                </li>
              </ul>
            </div>

            <div className="text-sm text-gray-500">
              <p>Need help? Contact us at <span className="text-blue-600">info@functioninstitute.com</span></p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // STATE 3: Test completed but no enrollment - Show waiting message
  if (hasCompletedTest && !hasCurrentTermEnrollment) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Welcome, {student?.firstName} {student?.secondName}!
              </h1>
              <p className="text-gray-600">Function Institute Student Portal</p>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 text-gray-600 hover:text-gray-900"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="text-6xl mb-6">🎉</div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Test Completed Successfully!
            </h2>
            
            {/* Show student's level */}
            <div className="mb-8">
              <p className="text-gray-600 mb-4">Your assessed level:</p>
              <div className="inline-block px-6 py-3 bg-blue-100 text-blue-800 rounded-lg text-2xl font-bold border-2 border-blue-300">
                {student?.currentLevel}
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
              <div className="flex items-start gap-4">
                <div className="text-4xl">⏳</div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    Processing Your Results
                  </h3>
                  <p className="text-gray-700">
                    Thank you for completing the placement test! Our team is currently 
                    reviewing your results and preparing your detailed report.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="text-4xl">📧</div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    Next Steps
                  </h3>
                  <p className="text-gray-700 mb-4">
                    We will send you a detailed report shortly via email and you will be 
                    enrolled in the appropriate class level. You will receive:
                  </p>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      <span>Detailed performance report</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      <span>Class schedule and enrollment details</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      <span>Payment information</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-green-600">✓</span>
                      <span>Access to learning materials</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="mt-8 text-sm text-gray-500">
              <p>Need help? Contact us at <span className="text-blue-600">info@functioninstitute.com</span></p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // STATE 4: Has current term enrollment - Show normal dashboard
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Welcome, {student?.firstName} {student?.secondName}!
            </h1>
            <p className="text-gray-600">Function Institute Student Portal</p>
          </div>
          <button
            onClick={handleLogout}
            className="px-4 py-2 text-gray-600 hover:text-gray-900"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Student Info Card */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Student Profile</h2>
              <p className="text-gray-600 mt-1">Current Level: <span className="font-semibold text-blue-600">{student?.currentLevel}</span></p>
            </div>
          </div>
        </div>

        {/* Announcements Section */}
        {announcements.length > 0 && (
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">📢 Announcements</h2>
            <div className="space-y-4">
              {announcements.map((announcement) => (
                <div 
                  key={announcement.id} 
                  className={`border-l-4 rounded-r-lg p-4 ${
                    announcement.priority === 'HIGH' ? 'border-red-500 bg-red-50' :
                    announcement.priority === 'MEDIUM' ? 'border-yellow-500 bg-yellow-50' :
                    'border-blue-500 bg-blue-50'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-gray-900">{announcement.title}</h3>
                      <p className="text-gray-700 mt-1">{announcement.content}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                        <span>📅 {new Date(announcement.createdAt).toLocaleDateString()}</span>
                        {announcement.teacher && (
                          <span>👤 {announcement.teacher.firstName} {announcement.teacher.lastName}</span>
                        )}
                        {announcement.group && (
                          <span className="bg-white px-2 py-0.5 rounded border border-gray-200">
                            {announcement.group.groupCode}
                          </span>
                        )}
                      </div>
                    </div>
                    {announcement.priority === 'HIGH' && (
                      <span className="px-2 py-1 bg-red-100 text-red-800 text-xs font-bold rounded">
                        URGENT
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Active Enrollments */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">My Classes</h2>
          <div className="space-y-4">
            {student?.enrollments.filter(e => e.status === 'ACTIVE' && e.term?.isCurrent).map((enrollment) => (
              <div key={enrollment.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900">{enrollment.group.name}</h3>
                    <p className="text-gray-600 text-sm">Level: {enrollment.group.level.name}</p>
                  </div>
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
                    Active
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => router.push('/student/schedule')}
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition text-center"
          >
            <div className="text-4xl mb-3">📅</div>
            <h3 className="font-semibold text-gray-900">My Schedule</h3>
            <p className="text-sm text-gray-600 mt-1">View class times</p>
          </button>

          <button
            onClick={() => router.push('/student/attendance')}
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition text-center"
          >
            <div className="text-4xl mb-3">✓</div>
            <h3 className="font-semibold text-gray-900">Attendance</h3>
            <p className="text-sm text-gray-600 mt-1">View attendance record</p>
          </button>

          <button
            onClick={() => router.push('/student/materials')}
            className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition text-center"
          >
            <div className="text-4xl mb-3">📚</div>
            <h3 className="font-semibold text-gray-900">Materials</h3>
            <p className="text-sm text-gray-600 mt-1">Access learning materials</p>
          </button>
        </div>
      </div>
    </div>
  );
}